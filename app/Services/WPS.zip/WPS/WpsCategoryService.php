<?php

namespace App\Services\WPS;

use App\Models\WPS\WpsProduct;
use App\Models\WPS\WpsProductItem;
use Webkul\Category\Models\Category;
use Webkul\Category\Models\CategoryTranslation;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class WpsCategoryService
{
    // protected $apiService;
    // protected $defaultLocale = 'en';
    // protected $categoryCache = [];

    // public function __construct(WpsApiService $apiService)
    // {
    //     $this->apiService = $apiService;
    //     $this->loadCategoryCache();
    // }

    // /**
    //  * Load existing categories into cache
    //  */
    // protected function loadCategoryCache()
    // {
    //     $categories = Category::with('translations')->get();
    //     foreach ($categories as $category) {
    //         $translation = $category->translations->where('locale', $this->defaultLocale)->first();
    //         if ($translation) {
    //             $this->categoryCache[strtolower($translation->name)] = $category->id;
    //         }
    //     }
    // }

    // /**
    //  * Sync categories for all products that have Bagisto products
    //  */
    // public function syncCategoriesForProducts($limit = 100)
    // {
    //     Log::channel('wps')->info('Starting category sync for products', ['limit' => $limit]);

    //     $wpsProducts = WpsProduct::with('items')
    //         ->whereNotNull('bagisto_product_id')
    //         ->limit($limit)
    //         ->get();

    //     $processed = 0;
    //     $errors = 0;

    //     foreach ($wpsProducts as $wpsProduct) {
    //         try {
    //             // Get any eligible item from this product to fetch categories
    //             $item = $wpsProduct->items()->dropShipEligible()->first();

    //             if ($item) {
    //                 $this->syncCategoriesForProduct($wpsProduct, $item);
    //                 $processed++;
    //             }

    //         } catch (\Exception $e) {
    //             $errors++;
    //             Log::channel('wps')->error('Failed to sync categories for product', [
    //                 'wps_product_id' => $wpsProduct->wps_product_id,
    //                 'error' => $e->getMessage()
    //             ]);
    //         }
    //     }

    //     Log::channel('wps')->info('Category sync completed', [
    //         'processed' => $processed,
    //         'errors' => $errors
    //     ]);

    //     return ['processed' => $processed, 'errors' => $errors];
    // }

    // /**
    //  * Sync categories for a single product
    //  */
    // public function syncCategoriesForProduct($wpsProduct, $wpsItem)
    // {
    //     // Fetch attribute values (categories) from WPS API
    //     $attributeResponse = $this->apiService->getItemAttributeValues($wpsItem->wps_item_id);

    //     if (!$attributeResponse || !isset($attributeResponse['data'])) {
    //         throw new \Exception('Failed to fetch attribute values');
    //     }

    //     $categoryIds = [];

    //     foreach ($attributeResponse['data'] as $attributeValue) {
    //         $categoryId = $this->getOrCreateCategory($attributeValue['name']);
    //         if ($categoryId) {
    //             $categoryIds[] = $categoryId;
    //         }
    //     }

    //     // Assign product to categories
    //     if (!empty($categoryIds)) {
    //         $this->assignProductToCategories($wpsProduct->bagisto_product_id, $categoryIds);
    //     }

    //     Log::channel('wps')->info('Synced categories for product', [
    //         'wps_product_id' => $wpsProduct->wps_product_id,
    //         'bagisto_product_id' => $wpsProduct->bagisto_product_id,
    //         'categories' => count($categoryIds)
    //     ]);
    // }

    // /**
    //  * Get existing category or create new one
    //  */
    // protected function getOrCreateCategory($categoryName)
    // {
    //     $categoryKey = strtolower(trim($categoryName));

    //     // Check cache first
    //     if (isset($this->categoryCache[$categoryKey])) {
    //         return $this->categoryCache[$categoryKey];
    //     }

    //     // Try to find existing category
    //     $existing = CategoryTranslation::where('locale', $this->defaultLocale)
    //         ->where('name', $categoryName)
    //         ->first();

    //     if ($existing) {
    //         $this->categoryCache[$categoryKey] = $existing->category_id;
    //         return $existing->category_id;
    //     }

    //     // Create new category
    //     return $this->createNewCategory($categoryName);
    // }

    // /**
    //  * Create a new category
    //  */
    // protected function createNewCategory($categoryName)
    // {
    //     try {
    //         DB::beginTransaction();

    //         // Create category
    //         $category = Category::create([
    //             'position' => 1,
    //             'status' => 1,
    //             'parent_id' => 1, // Root category
    //         ]);

    //         $slug = $this->generateSlug($categoryName, $category->id);

    //         // Use direct DB insertion instead of model to avoid fillable restrictions
    //         DB::table('category_translations')->insert([
    //             'category_id' => $category->id,  // This is crucial!
    //             'locale' => $this->defaultLocale,
    //             'name' => $categoryName,
    //             'slug' => $slug,
    //             'url_path' => $slug,
    //             'description' => "WPS category: {$categoryName}",
    //             'meta_title' => $categoryName,
    //             'meta_description' => "Products in {$categoryName} category",
    //             'meta_keywords' => strtolower($categoryName),
    //             'locale_id' => 1, // Direct value instead of method call
    //         ]);

    //         DB::commit();

    //         // Update cache
    //         $this->categoryCache[strtolower($categoryName)] = $category->id;

    //         Log::channel('wps')->info('Created new category', [
    //             'category_id' => $category->id,
    //             'name' => $categoryName
    //         ]);

    //         return $category->id;

    //     } catch (\Exception $e) {
    //         DB::rollBack();
    //         Log::channel('wps')->error('Failed to create category', [
    //             'name' => $categoryName,
    //             'error' => $e->getMessage()
    //         ]);
    //         return null;
    //     }
    // }

    // /**
    //  * Get locale ID for the current locale
    //  */
    // protected function getLocaleId()
    // {
    //     try {
    //         $locale = DB::table('locales')->where('code', $this->defaultLocale)->first();
    //         return $locale ? $locale->id : 1; // Default to 1 for 'en'
    //     } catch (\Exception $e) {
    //         return 1; // Fallback to ID 1
    //     }
    // }

    // /**
    //  * Assign product to categories
    //  */
    // protected function assignProductToCategories($productId, $categoryIds)
    // {
    //     // Remove existing category assignments
    //     DB::table('product_categories')
    //         ->where('product_id', $productId)
    //         ->delete();

    //     // Add new category assignments
    //     foreach ($categoryIds as $categoryId) {
    //         DB::table('product_categories')->insert([
    //             'product_id' => $productId,
    //             'category_id' => $categoryId,
    //         ]);
    //     }
    // }

    // /**
    //  * Generate category slug
    //  */
    // protected function generateSlug($name, $categoryId)
    // {
    //     $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
    //     return $slug . '-' . $categoryId;
    // }
}