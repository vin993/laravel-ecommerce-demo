<?php

namespace App\Services\WPS;

use App\Models\WPS\WpsProduct;
use App\Models\WPS\WpsProductItem;
use Webkul\Product\Models\Product;
use Webkul\Category\Models\Category;
use Webkul\Product\Models\ProductAttributeValue;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class WpsBagistoService
{
    protected $apiService;
    protected $defaultAttributeFamily;
    protected $defaultChannel = 'default';
    protected $defaultLocale = 'en';
    protected $attributeMap;

    public function __construct(WpsApiService $apiService)
    {
        $this->apiService = $apiService;
        $this->defaultAttributeFamily = \Webkul\Attribute\Models\AttributeFamily::first();
        $this->initAttributeMap();
    }

    /**
     * Initialize attribute mapping based on actual Bagisto attributes
     */
    protected function initAttributeMap()
    {
        $this->attributeMap = [
            'sku' => 1,
            'name' => 2,
            'url_key' => 3,
            'tax_category_id' => 4,
            'new' => 5,
            'featured' => 6,
            'visible_individually' => 7,
            'status' => 8,
            'short_description' => 9,
            'description' => 10,
            'price' => 11,
            'cost' => 12,
            'special_price' => 13,
            'special_price_from' => 14,
            'special_price_to' => 15,
            'meta_title' => 16,
            'meta_keywords' => 17,
            'meta_description' => 18,
            'length' => 19,
            'width' => 20,
            'height' => 21,
            'weight' => 22,
        ];
    }

    /**
     * Create Bagisto products from WPS data with dimensions
     */
    public function createBagistoProducts($limit = 100)
    {
        Log::channel('wps')->info('Starting Bagisto product creation with dimensions', ['limit' => $limit]);

        $wpsProducts = WpsProduct::with(['items' => function($query) {
            $query->dropShipEligible()->available();
        }])
            ->whereNull('bagisto_product_id')
            ->where('status', 'synced')
            ->limit($limit)
            ->get();

        $created = 0;
        $skipped = 0;
        $errors = 0;

        foreach ($wpsProducts as $wpsProduct) {
            try {
                $result = $this->createSingleBagistoProduct($wpsProduct);
                
                if ($result['created']) {
                    $created++;
                    Log::channel('wps')->info('Created Bagisto product', [
                        'wps_product_id' => $wpsProduct->wps_product_id,
                        'bagisto_product_id' => $wpsProduct->bagisto_product_id,
                        'name' => $wpsProduct->name,
                        'has_dimensions' => $result['has_dimensions']
                    ]);
                } else {
                    $skipped++;
                    Log::channel('wps')->warning('Skipped product creation', [
                        'wps_product_id' => $wpsProduct->wps_product_id,
                        'reason' => $result['reason']
                    ]);
                }

            } catch (\Exception $e) {
                $errors++;
                Log::channel('wps')->error('Failed to create Bagisto product', [
                    'wps_product_id' => $wpsProduct->wps_product_id,
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString()
                ]);
            }
        }

        Log::channel('wps')->info('Bagisto product creation completed', [
            'created' => $created,
            'skipped' => $skipped,
            'errors' => $errors
        ]);

        return ['created' => $created, 'skipped' => $skipped, 'errors' => $errors];
    }

    /**
     * Create a single Bagisto product with enhanced validation
     */
    protected function createSingleBagistoProduct($wpsProduct)
    {
        DB::beginTransaction();

        try {
            $eligibleItems = $wpsProduct->items;

            if ($eligibleItems->isEmpty()) {
                return ['created' => false, 'reason' => 'No eligible items found'];
            }

            // Prefer items with dimensions
            $itemsWithDimensions = $eligibleItems->filter(function($item) {
                return $item->hasDimensions();
            });

            $mainItem = $itemsWithDimensions->isNotEmpty() 
                ? $itemsWithDimensions->first() 
                : $eligibleItems->first();

            // Check if item has minimum required data
            if (!$this->hasMinimumRequiredData($mainItem)) {
                return ['created' => false, 'reason' => 'Missing required data (price, name, etc.)'];
            }

            $bagistoProduct = $this->createSimpleProduct($wpsProduct, $mainItem);

            $wpsProduct->update(['bagisto_product_id' => $bagistoProduct->id]);
            $mainItem->update(['bagisto_product_id' => $bagistoProduct->id]);

            DB::commit();

            return [
                'created' => true, 
                'has_dimensions' => $mainItem->hasDimensions(),
                'product' => $bagistoProduct
            ];

        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }

    /**
     * Check if item has minimum required data for Bagisto
     */
    protected function hasMinimumRequiredData($wpsItem)
    {
        return !empty($wpsItem->sku) && 
               !empty($wpsItem->name) && 
               ($wpsItem->getEffectivePrice() > 0);
    }

    /**
     * Create simple product with enhanced attributes
     */
    protected function createSimpleProduct($wpsProduct, $wpsItem)
    {
        $productData = [
            'type' => 'simple',
            'sku' => $wpsItem->sku,
            'parent_id' => null,
            'attribute_family_id' => $this->defaultAttributeFamily->id,
            'api_source' => 'wps',
            'external_id' => (string) $wpsProduct->wps_product_id,
        ];

        $product = Product::create($productData);
        $this->addProductAttributes($product, $wpsProduct, $wpsItem);
        $this->addToDefaultCategory($product);

        // Update inventory
        app(WpsInventoryService::class)->updateBagistoInventory(
            $product->id,
            $wpsItem->inventory_total
        );

        return $product;
    }

    /**
     * Add product attributes with dimensions and enhanced data
     */
    protected function addProductAttributes($product, $wpsProduct, $wpsItem)
    {
        $effectivePrice = $wpsItem->getEffectivePrice();
        
        $attributes = [
            'name' => $wpsProduct->name,
            'url_key' => $this->generateUrlKey($wpsProduct->name, $product->id),
            'short_description' => $this->truncateText($wpsProduct->description, 255),
            'description' => $wpsProduct->description,
            'price' => $effectivePrice,
            'cost' => $wpsItem->cost ?? $wpsItem->dealer_price,
            'status' => $wpsItem->is_available && $wpsItem->inventory_total > 0,
            'visible_individually' => true,
            'new' => $wpsItem->is_new,
            'featured' => $wpsItem->is_featured,
            'meta_title' => $wpsProduct->name,
            'meta_description' => $this->truncateText($wpsProduct->description, 160),
        ];

        // Add dimensions if available
        if ($wpsItem->hasDimensions()) {
            $attributes['weight'] = $wpsItem->weight;
            $attributes['length'] = $wpsItem->length;
            $attributes['width'] = $wpsItem->width;
            $attributes['height'] = $wpsItem->height;
            
            Log::channel('wps')->info('Adding dimensions to product', [
                'product_id' => $product->id,
                'weight' => $wpsItem->weight,
                'length' => $wpsItem->length,
                'width' => $wpsItem->width,
                'height' => $wpsItem->height
            ]);
        } else {
            Log::channel('wps')->warning('Product created without dimensions', [
                'product_id' => $product->id,
                'sku' => $wpsItem->sku,
                'note' => 'Product may not display properly on frontend'
            ]);
        }

        // Add special pricing if available
        if ($wpsItem->special_price && $wpsItem->isSpecialPriceActive()) {
            $attributes['special_price'] = $wpsItem->special_price;
            
            if ($wpsItem->special_price_from) {
                $attributes['special_price_from'] = $wpsItem->special_price_from;
            }
            
            if ($wpsItem->special_price_to) {
                $attributes['special_price_to'] = $wpsItem->special_price_to;
            }
        }

        // Add each attribute
        foreach ($attributes as $code => $value) {
            $this->addSingleAttribute($product, $code, $value);
        }
    }

    /**
     * Add a single attribute to product with better error handling
     */
    protected function addSingleAttribute($product, $code, $value)
    {
        if (!isset($this->attributeMap[$code])) {
            Log::channel('wps')->debug('Attribute not mapped, skipping', ['code' => $code]);
            return;
        }

        $attributeId = $this->attributeMap[$code];

        try {
            $data = [
                'product_id' => $product->id,
                'attribute_id' => $attributeId,
                'locale' => $this->defaultLocale,
                'channel' => $this->defaultChannel,
                'unique_id' => $this->defaultChannel . '|' . $this->defaultLocale . '|' . $product->id . '|' . $attributeId,
            ];

            // Set the appropriate value field based on type
            if (is_bool($value)) {
                $data['boolean_value'] = $value;
            } elseif (is_numeric($value)) {
                $data['float_value'] = (float) $value;
            } elseif ($value instanceof \Carbon\Carbon || is_string($value) && strtotime($value)) {
                $data['date_value'] = is_string($value) ? $value : $value->toDateString();
            } else {
                $data['text_value'] = (string) $value;
            }

            ProductAttributeValue::create($data);

        } catch (\Exception $e) {
            Log::channel('wps')->error('Failed to add attribute', [
                'product_id' => $product->id,
                'attribute_code' => $code,
                'value' => $value,
                'error' => $e->getMessage()
            ]);
        }
    }

    /**
     * Generate URL key
     */
    protected function generateUrlKey($name, $productId)
    {
        $urlKey = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
        return $urlKey . '-' . $productId;
    }

    /**
     * Add product to default category
     */
    protected function addToDefaultCategory($product)
    {
        try {
            // Use category ID 1 for now (root category)
            DB::table('product_categories')->insert([
                'product_id' => $product->id,
                'category_id' => 1,
            ]);
        } catch (\Exception $e) {
            Log::channel('wps')->error('Failed to add product to category', [
                'product_id' => $product->id,
                'error' => $e->getMessage()
            ]);
        }
    }

    /**
     * Truncate text to specified length
     */
    protected function truncateText($text, $length)
    {
        if (!$text || strlen($text) <= $length) {
            return $text;
        }

        return substr($text, 0, $length - 3) . '...';
    }

    /**
     * Get statistics about products with/without dimensions
     */
    public function getDimensionStats()
    {
        $totalItems = WpsProductItem::dropShipEligible()->count();
        $itemsWithDimensions = WpsProductItem::dropShipEligible()->withDimensions()->count();
        $bagistoProducts = WpsProduct::whereNotNull('bagisto_product_id')->count();
        
        return [
            'total_eligible_items' => $totalItems,
            'items_with_dimensions' => $itemsWithDimensions,
            'items_without_dimensions' => $totalItems - $itemsWithDimensions,
            'bagisto_products_created' => $bagistoProducts,
            'dimension_coverage_percent' => $totalItems > 0 ? round(($itemsWithDimensions / $totalItems) * 100, 2) : 0
        ];
    }
}